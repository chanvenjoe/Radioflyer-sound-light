#define PortB_PU 0x04
#define PortB_PD 0x00
#define Sensitivity 100
#define clr_Tcnt Touch_cnt=0;

void touch_init();
void touch_IRS();