

#ifndef _GLOBAL_FUNCTIONS_
#define _GLOBAL_FUNCTIONS_

#include <stdint.h>

extern void Initial(void);
extern void DoADPCM(void);


#endif



