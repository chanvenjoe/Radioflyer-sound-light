

#ifndef _PROJECT_CONFIG_FILE_

#pragma comment(CONST, "_PROJECT_CONFIG_FILE_")

// -------- compiler configure ------

#pragma comment(OPTION, "no-fplib")		// not use float point


// -------- library configure (libadpcm) ------

#pragma inclib("libadpcm")

#endif


